Template Name: AppSpot
Template URI: http://www.wpfreeware.com/appspot-best-file-sharing-wordpress-theme/
Author: WpFreeware
Author URI: http://www.wpfreeware.com
Description: A Pro Apps / Digital Downloads html template
Version: 1.0 
License: GPL
License URI: http://www.gnu.org/licenses/gpl-2.0.html


////////////////////////////////////////////////////////////////////////

Wordpress version also available here: 
http://www.wpfreeware.com/appspot-best-file-sharing-wordpress-theme/

//////////////////////////////////////////////////////////////////////



---------------------------------------------
Find more great resources @ WpFreeware.com
Sincerely,
The WpFreeware Team.
---------------------------------------------
http://www.wpfreeware.com
PS. Those terms might change as we update our license on our website, 
please be sure to check the latest license terms on our website to avoid any misuse of our resources.

Thank you!